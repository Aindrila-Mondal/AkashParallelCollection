package com.cg.xyzbank.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

import com.cg.xyzbank.bean.Customer;
import com.cg.xyzbank.bean.Customer2;
import com.cg.xyzbank.dao.CustomerDaoImpl;
import com.cg.xyzbank.dao.ICustomerDao;
import com.cg.xyzbank.exception.BankException;

public class CustomerServiceImpl implements ICustomerService{

	ICustomerDao objDao=new CustomerDaoImpl();


	@Override
	public HashMap<Integer, Customer2> showdetails() throws BankException {
		// TODO Auto-generated method stub
		return objDao.showdetails();
	}

	@Override
	public void withdraw(int accNoCustomer,double balanceToWithdraw) throws BankException {
		// TODO Auto-generated method stub
		objDao.withdraw(accNoCustomer,balanceToWithdraw);
	}
	public void deposit(int accNoCustomerDepositer,double balanceToDeposit) throws BankException {
		// TODO Auto-generated method stub
		objDao.deposit(accNoCustomerDepositer,balanceToDeposit);
	}
	public String transaction(int idSender,int idReceiver,double amountToTransfer) throws BankException
	{
		return objDao.transaction(idSender,idReceiver,amountToTransfer);
	}

	@Override
	public Customer2 search(String nameToSearch) throws BankException {
		// TODO Auto-generated method stub
		return objDao.search(nameToSearch);
	}

	@Override
	public ArrayList<String> printTransaction(int accNoToFindTransactionDetails) throws BankException {
		// TODO Auto-generated method stub
		return objDao.printTransaction(accNoToFindTransactionDetails);
		
	}

	@Override
	public int putdata(String name, long contact,String mail, double balance) throws BankException{
		// TODO Auto-generated method stub
		return objDao.putdata(name, contact,mail, balance);
	}

	@Override
	public boolean isNameValid(String name) {
		// TODO Auto-generated method stub
		boolean result=false;
		String regExName="[A-Z][a-z]{3,15}";
		if(name.matches(regExName))
		{
			result=true;
		}
		return result;
	}

	@Override
	public boolean isContactValid(long contact) {
		// TODO Auto-generated method stub
		boolean result=false;
		String regExContact="[6-9][0-9]{9,9}";
		String contactString=Long.toString(contact);
		String contactStrTrimmed=contactString.trim();
	
		if(contactStrTrimmed.matches(regExContact))
		{
			result=true;
		}
	
		return result;
	}

	@Override
	public boolean isDOBValid(String dateOfBirth) {
		// TODO Auto-generated method stub
		
		boolean result=false;
		
		String regExDOB="[0-9]{4,4}[-][0-9]{2,2}[-][0-9]{2,2}";

		if(dateOfBirth.matches(regExDOB))
		{
			result=true;
		}
		
		return result;
	}

	@Override
	public boolean isMailValid(String mail) {
		// TODO Auto-generated method stub
		
		boolean result=false;
		String regExMail="[a-zA-Z0-9]+[@][a-zA-Z0-9]+([.][a-zA-Z]{2,})+)";
		if(mail.matches(regExMail))
		{
			result=true;
		}
		return result;
	}
	

}
