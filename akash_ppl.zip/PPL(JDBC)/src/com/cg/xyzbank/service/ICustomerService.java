package com.cg.xyzbank.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

import com.cg.xyzbank.bean.Customer;
import com.cg.xyzbank.bean.Customer2;
import com.cg.xyzbank.exception.BankException;

public interface ICustomerService {
	
	public int putdata(String name,long contact,String mail,double balance) throws BankException;
	public HashMap<Integer, Customer2> showdetails() throws BankException;
	public void withdraw(int accNoCustomer,double balanceToWithdraw) throws BankException;
	public void deposit(int accNoCustomerDepositer,double balanceToDeposit) throws BankException;
	public String transaction(int idSender,int idReceiver,double amountToTransfer) throws BankException;
	public Customer2 search(String nameToSearch) throws BankException;
	public ArrayList<String> printTransaction(int accNoToFindTransactionDetails) throws BankException;
	
	public boolean isNameValid(String name);
	public boolean isContactValid(long contact);
	public boolean isDOBValid(String dateOfBirth);
	public boolean isMailValid(String mail);
}
