
package com.cg.xyzbank.dao;

public interface QueryMapping {

	public static final String INSERT_QUERY="INSERT INTO CustomerXYZ VALUES(pid_seq.nextval,?,?,?,?)";
	public static final String SEQ_QUERY="SELECT pid_seq.currVal FROM Dual";
	public static final String RETRIVE_QUERY="SELECT * FROM CustomerXYZ";
	public static final String RETRIVE_ON_ID_QUERY="SELECT * FROM CustomerXYZ WHERE Id=?";
	public static final String UPDATE_BALANCE="UPDATE CustomerXYZ SET balance=? WHERE Id=?";
	public static final String INSERT_TRANSACTION="INSERT INTO BankTransactionXYZ VALUES(?,?,?,?)";
	public static final String RETRIVE_TRANSACTION="SELECT * FROM BankTransactionXYZ";
	public static final String SELECT_ON_NAME="SELECT * FROM CustomerXYZ WHERE name=?";
	public static final String RETRIVE_TRANSACTION_BY_ID="SELECT * FROM BankTransactionXYZ WHERE Id=?";
	
}
