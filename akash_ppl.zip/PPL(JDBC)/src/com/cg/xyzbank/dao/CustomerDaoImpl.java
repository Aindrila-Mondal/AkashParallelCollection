package com.cg.xyzbank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import com.cg.xyzbank.bean.Customer;
import com.cg.xyzbank.bean.Customer2;
import com.cg.xyzbank.exception.BankException;
import com.cg.xyzbank.util.CollectionUtil;
import com.cg.xyzbank.util.ConnectionFactory;



public class CustomerDaoImpl implements ICustomerDao
{


	CollectionUtil objCollectionUtil=new CollectionUtil();
	
	Connection con=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	
	
	public int putdata( String name, long contact,String mail, double balance) throws BankException 
	{
		// TODO Auto-generated method stub
		int generatedId=0;
		try {
			
		con=ConnectionFactory.getSigtonObj().getConnection();
		
		if(con==null)
		{
			throw new BankException("Connection not Establish");
		}
			
		ps=con.prepareStatement(QueryMapping.INSERT_QUERY);
		
		ps.setString(1,name);
		ps.setLong(2, contact);
		ps.setDouble(3, balance);
		ps.setString(4, mail);
		ps.executeUpdate();
		
		ps=con.prepareStatement(QueryMapping.RETRIVE_QUERY);
		rs=ps.executeQuery();
		rs.next();
		generatedId=rs.getInt(1);
		
		}
		catch(SQLException  e) {
			throw new BankException("Problem in Executing Query"+e.getMessage());
			
		}
		finally
		{
			try {
				if(con==null || ps==null || rs==null)
				{
					throw new BankException("Connection Not Done");
				}
				con.close();
				ps.close();
				rs.close();
			}
			catch (SQLException e) {
				// TODO: handle exception
				throw new BankException("Connection Not Done SQL exp");
			}
			catch (Exception e2) {
				// TODO: handle exception
				throw new BankException("Connection Not Done exp");
			}
		}
		
		return generatedId;
		
	}

	@Override
	public HashMap<Integer, Customer2> showdetails() throws BankException {
		// TODO Auto-generated method stub
		HashMap<Integer,Customer2> allDetailsHashMap=new HashMap<>();
		
		try {
			
		con=ConnectionFactory.getSigtonObj().getConnection();
		
		if(con==null)
		{
			throw new BankException("Connection not Establish");
		}
			
		ps=con.prepareStatement(QueryMapping.RETRIVE_QUERY);	
		ps.executeQuery();
		while(rs.next()) 
		{
			Customer2 customer=new Customer2();
			
			customer.setName(rs.getString(2));
			customer.setNumber(rs.getLong(3));
			customer.setBalance(rs.getDouble(4));
			customer.setMail(rs.getString(5));
			
			allDetailsHashMap.put(rs.getInt(1), customer);
		}
		
		
		
		}
		catch(SQLException | NullPointerException e) {
			throw new BankException("Problem in Executing Query"+e.getMessage());
			
		}
		finally
		{
			try {
				if(con==null || ps==null || rs==null)
				{
					throw new BankException("Connection Not Done");
				}
				con.close();
				ps.close();
				rs.close();
			}
			catch (SQLException e) {
				// TODO: handle exception
				throw new BankException("Connection Not Done SQL exp");
			}
			catch (Exception e2) {
				// TODO: handle exception
				throw new BankException("Connection Not Done exp");
			}
		}
		
		return allDetailsHashMap;
		
	
	}

	@Override
	public void withdraw(int accNo, double balanceToWithdraw) throws BankException {
		// TODO Auto-generated method stub
		try {
			
		con=ConnectionFactory.getSigtonObj().getConnection();
		
		if(con==null)
		{
			throw new BankException("Connection not Establish");
		}
		ps=con.prepareStatement(QueryMapping.RETRIVE_ON_ID_QUERY);
		ps.setInt(1, accNo);
		rs=ps.executeQuery();
		rs.next();
		String name=rs.getString(2);
		double cuurentBalance=rs.getDouble(4);

		if(cuurentBalance>balanceToWithdraw)
		{
			double temporarayBalance=cuurentBalance-balanceToWithdraw;
			if(temporarayBalance>500)
			{
			
				ps=con.prepareStatement(QueryMapping.UPDATE_BALANCE);
				ps.setDouble(1,temporarayBalance);
				ps.setInt(2, accNo);
				ps.executeUpdate();
				
				ps=con.prepareStatement(QueryMapping.INSERT_TRANSACTION);
				ps.setInt(1,accNo);
				String details=name+" Debited "+balanceToWithdraw+" on ";
				ps.setString(2,details);
				ps.setDate(3, Date.valueOf(LocalDate.now()));
				String time=LocalTime.now()+"";
				ps.setString(4, time);
				ps.executeUpdate();
				
				
				
			}
			else
			{
				throw new BankException("sorry you do not have enough balance min Balance in account policy is violated");
			}
				
		}
		else
			throw new BankException("sorry you do not have enough balance");
		}
		catch(SQLException exp)
		{
			throw new BankException("Problem in Executing Query"+exp.getMessage());
			
		}
		catch(NullPointerException exp2)
		{
			throw new BankException("Invalid Account"+exp2.getMessage());
			
		}
		finally
		{
				try {
					if(con==null || ps==null || rs==null)
					{
						throw new BankException("Connection Not Done");
					}
					con.close();
					ps.close();
					rs.close();
				}
				catch (SQLException e) {
					// TODO: handle exception
					throw new BankException("Connection Not Done SQL exp");
				}
				catch (Exception e2) {
					// TODO: handle exception
					throw new BankException("Connection Not Done exp");
				}
		}
	}

	@Override
	public void deposit(int accNo, double balanceToDeposit) throws BankException {
		
		// TODO Auto-generated method stub
		try {
			
		con=ConnectionFactory.getSigtonObj().getConnection();
		
		if(con==null)
		{
			throw new BankException("Connection not Establish");
		}
		ps=con.prepareStatement(QueryMapping.RETRIVE_ON_ID_QUERY);
		ps.setInt(1, accNo);
		rs=ps.executeQuery();
		rs.next();
		String name=rs.getString(2);
		double cuurentBalance=rs.getDouble(4);

	
				double temporarayBalance=cuurentBalance+balanceToDeposit;
			
			
				ps=con.prepareStatement(QueryMapping.UPDATE_BALANCE);
				ps.setDouble(1,temporarayBalance);
				ps.setInt(2, accNo);
				ps.executeUpdate();
				
				ps=con.prepareStatement(QueryMapping.INSERT_TRANSACTION);
				ps.setInt(1,accNo);
				String details=name+" Credited"+balanceToDeposit+" on ";
				ps.setString(2,details);
				ps.setDate(3, Date.valueOf(LocalDate.now()));
				String time=LocalTime.now()+"";
				ps.setString(4, time);
				ps.executeUpdate();
				
				
				
			
				
		}
		catch(SQLException exp)
		{
			throw new BankException("Problem in Executing Query"+exp.getMessage());
			
		}
		catch(NullPointerException exp2)
		{
			throw new BankException("Invalid Account"+exp2.getMessage());
			
		}
		finally
		{
				try {
					if(con==null || ps==null || rs==null)
					{
						throw new BankException("Connection Not Done");
					}
					con.close();
					ps.close();
					rs.close();
				}
				catch (SQLException e) {
					// TODO: handle exception
					throw new BankException("Connection Not Done SQL exp");
				}
				catch (Exception e2) {
					// TODO: handle exception
					throw new BankException("Connection Not Done exp");
				}
		}
		
	}
	public String transaction(int idSender,int idReceiver,double amountToTransfer) throws BankException
	{
		
		String transactionDetail="";
		
		try {
			
			con=ConnectionFactory.getSigtonObj().getConnection();
			
			if(con==null)
			{
				throw new BankException("Connection not Establish");
			}
		
		ps=con.prepareStatement(QueryMapping.RETRIVE_ON_ID_QUERY);
		ps.setInt(1,idSender);
		rs=ps.executeQuery();
		rs.next();
		String nameSender=rs.getString(2);
		double currentBalanceSender=rs.getDouble(4);
		if(currentBalanceSender>amountToTransfer)
		{
			double temporaryBalSender=currentBalanceSender-amountToTransfer;
			if(temporaryBalSender>500)
			{
				
				ps=con.prepareStatement(QueryMapping.RETRIVE_ON_ID_QUERY);
				ps.setInt(1,idReceiver);
				ResultSet rs2=ps.executeQuery();
				rs2.next();
				String nameReceiver=rs2.getString(2);
				double currentBalanceReceiver=rs2.getDouble(4)+amountToTransfer;
				
				
					ps=con.prepareStatement(QueryMapping.UPDATE_BALANCE);
					ps.setDouble(1,currentBalanceReceiver);
					ps.setInt(2, idReceiver);
					ps.executeUpdate();
					
					ps=con.prepareStatement(QueryMapping.INSERT_TRANSACTION);
					ps.setInt(1,idSender);
					String details=nameSender+" Transfered "+amountToTransfer+" to "+ nameReceiver;
					ps.setString(2,details);
					transactionDetail=details;
					ps.setDate(3, Date.valueOf(LocalDate.now()));
					String timeSender=LocalTime.now()+"";
					ps.setString(4, timeSender);
					ps.executeUpdate();
					
					ps=con.prepareStatement(QueryMapping.UPDATE_BALANCE);
					ps.setDouble(1,temporaryBalSender);
					ps.setInt(2, idSender);
					ps.executeUpdate();
					
					
					ps=con.prepareStatement(QueryMapping.INSERT_TRANSACTION);
					ps.setInt(1,idReceiver);
					String details2=nameSender+" Credited With "+amountToTransfer+" from "+ nameReceiver;
					ps.setString(2,details2);
					ps.setDate(3, Date.valueOf(LocalDate.now()));
					String timeReceiver=LocalTime.now()+"";
					ps.setString(4, timeReceiver);
					ps.executeUpdate();
					
					
			
			}
			else
			{
				throw new BankException("sorry you do not have enough balance min Balance in account policy is violated");
			}
				
		}
		else
			throw new BankException("sorry you do not have enough balance");
		}
		catch(SQLException exp)
		{
			throw new BankException("Problem in Executing Query"+exp.getMessage());
			
		}
		catch(NullPointerException exp2)
		{
			throw new BankException("Invalid Account"+exp2.getMessage());
			
		}
		finally
		{
				try {
					if(con==null || ps==null || rs==null)
					{
						throw new BankException("Connection Not Done");
					}
					con.close();
					ps.close();
					rs.close();
				}
				catch (SQLException e) {
					// TODO: handle exception
					throw new BankException("Connection Not Done SQL exp");
				}
				catch (Exception e2) {
					// TODO: handle exception
					throw new BankException("Connection Not Done exp");
				}
		}
		
		return transactionDetail;
		
	}
	public Customer2 search(String customerToFindName) throws BankException
	{
		
		Customer2 customer=new Customer2();
		try {
			con=ConnectionFactory.getSigtonObj().getConnection();
			
			if(con==null)
			{
				throw new BankException("Connection not Establish");
			}
		
		ps=con.prepareStatement(QueryMapping.SELECT_ON_NAME);
		ps.setString(1,customerToFindName);
		rs=ps.executeQuery();
		rs.next();
		if(rs.next()) 
		{
			
			customer.setName(rs.getString(2));
			customer.setNumber(rs.getLong(3));
			customer.setBalance(rs.getDouble(4));
			customer.setMail(rs.getString(5));
		}
			
		}
		catch(SQLException exp)
		{
			throw new BankException("Problem in Executing Query"+exp.getMessage());
			
		}
		catch(NullPointerException exp2)
		{
			throw new BankException("Invalid Account"+exp2.getMessage());
			
		}
		finally
		{
				try {
					if(con==null || ps==null || rs==null)
					{
						throw new BankException("Connection Not Done");
					}
					con.close();
					ps.close();
					rs.close();
				}
				catch (SQLException e) {
					// TODO: handle exception
					throw new BankException("Connection Not Done SQL exp");
				}
				catch (Exception e2) {
					// TODO: handle exception
					throw new BankException("Connection Not Done exp");
				}
		}
		return customer;
	}
	public ArrayList<String> printTransaction(int accNoToFindTransactionDetails) throws BankException
	{
		ArrayList<String> customerAllTransaction = new ArrayList<>();
		try {
			con=ConnectionFactory.getSigtonObj().getConnection();
			
			if(con==null)
			{
				throw new BankException("Connection not Establish");
			}
		
		ps=con.prepareStatement(QueryMapping.RETRIVE_ON_ID_QUERY);
		ps.setInt(1,accNoToFindTransactionDetails);
		rs=ps.executeQuery();
	
		while(rs.next())
		{
			String detail = rs.getInt(1)+" "+rs.getString(2)+" "+rs.getDate(3)+" "+rs.getString(4);
			customerAllTransaction.add(detail);
		}
		}
		catch(SQLException exp)
		{
			throw new BankException("Problem in Executing Query"+exp.getMessage());
			
		}
		catch(NullPointerException exp2)
		{
			throw new BankException("Invalid Account"+exp2.getMessage());
			
		}
		finally
		{
				try {
					if(con==null || ps==null || rs==null)
					{
						throw new BankException("Connection Not Done");
					}
					con.close();
					ps.close();
					rs.close();
				}
				catch (SQLException e) {
					// TODO: handle exception
					throw new BankException("Connection Not Done SQL exp");
				}
				catch (Exception e2) {
					// TODO: handle exception
					throw new BankException("Connection Not Done exp");
				}
		}
		
		
		return customerAllTransaction;

		
	}

}
