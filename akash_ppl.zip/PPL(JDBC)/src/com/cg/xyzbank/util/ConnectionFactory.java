package com.cg.xyzbank.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.xyzbank.exception.BankException;

public class ConnectionFactory {

	private static ConnectionFactory sigtonObj;
	public static ConnectionFactory getSigtonObj()
	{
		if(sigtonObj==null)
			sigtonObj=new ConnectionFactory();
		return sigtonObj;
	}
	
	public Connection getConnection() throws BankException {
		
		Connection con=null;
		try {
			//FileInputStream fis=new FileInputStream("resource/oracledb.properties");
			//Properties prop=new Properties();
			//prop.load(fis);
			String driver="jdbc:oracle:thin:@localhost:1521:XE"; //prop.getProperty("db.driver");
			String url="jdbc:oracle:thin:@localhost:1521:XE";
			String user="system";
			String pwd="Capgemini123";
			Class.forName(driver);
			con=DriverManager.getConnection(url,user,pwd);
		}
		catch(ClassNotFoundException | SQLException exp)
		{
			throw new BankException("Problem in Connection creation, Might be DB issue");
		}
		return con;
		
	}
}
