package com.cg.xyzbank.util;

import java.util.ArrayList;
import java.util.HashMap;

import com.cg.xyzbank.bean.Customer;

public class CollectionUtil {
	
	
	private HashMap<Integer,Customer> allAccDetails=new HashMap<>();

	public HashMap<Integer, Customer> getAllAccDetails() {
		return allAccDetails;
	}

	public void setAllAccDetails(Customer customer) {
		this.allAccDetails.put(customer.getAccNo(), customer);
	}
	
	

}
