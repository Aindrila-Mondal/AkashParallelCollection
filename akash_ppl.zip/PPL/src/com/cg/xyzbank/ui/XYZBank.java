package com.cg.xyzbank.ui;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

import com.cg.xyzbank.bean.Customer;
import com.cg.xyzbank.exception.BankException;
import com.cg.xyzbank.service.CustomerServiceImpl;
import com.cg.xyzbank.service.ICustomerService;

public class XYZBank
{
 public static void main(String[] args) 
 	{
	 	Scanner sc=new Scanner(System.in);
	 	ICustomerService objService=new CustomerServiceImpl();
	 	Random random=new Random();
	 	
	 	char s;
	 	do
	 	{
	 		System.out.println("press 1 to create account\n 2 to show details \n 3 to withdraw \n 4 to deposit \n 5 to transfer money \n 6 to search any account \n 7 to print all transaction \n 8 to exit");
	 		int choice=sc.nextInt();
	 		switch(choice)
	 		{
	 		case 1:
	 				System.out.println("Enter Account Details");
	 				System.out.println("Enter Name");
	 				String name="";
	 				name=sc.next();
	 				while(!objService.isNameValid(name))
	 				{
	 					System.out.println("Enter Name Again");
	 					name=sc.next();
	 				}
	 				
	 				System.out.println("Enter Contact");
	 				long contact=sc.nextLong();
	 				while(!objService.isContactValid(contact))
	 				{
	 					System.out.println("Enter Contact Again");
	 					contact=sc.nextLong();
	 				}
	 				
	 				System.out.println("Enter Balance to Open Account");
	 				double balance=sc.nextDouble();
	 				while(balance<500)
	 				{
	 					try
	 					{
	 						throw new BankException("Minimum Balance to Open Account should be 500");
	 					}
	 					catch(BankException e)
	 					{
	 						System.out.println(e.getMessage());
	 					}
	 					
	 					System.out.println("Enter Balance More than 500 to Open Account");
	 					balance=sc.nextDouble();
	 					
	 				}
	 				
	 				System.out.println("Enter Date in YYYY-MM-DD fromat");
	 				int[] a=new int[3];
	 				String dobString=sc.next();
	 				String dobStringSplitted[]=dobString.split("-");
 					for(int i=0;i<=2;i++)
 					{
 					
 						a[i]=Integer.parseInt(dobStringSplitted[i]);
 					}
	 				while(!objService.isDOBValid(dobString))
	 				{
	 				
	 					System.out.println("Enter Date Again in YYYY-MM-DD");
	 					dobString=sc.next();
	 					String dobStringSplitted2[]=dobString.split("-");
	 					for(int i=0;i<=2;i++)
	 					{
	 					
	 						a[i]=Integer.parseInt(dobStringSplitted2[i]);
	 					}
	 				}
	 				
	 				LocalDate dateOfBirth=LocalDate.of(a[0], a[1], a[2]);
	 				int accNo=random.nextInt(100000);
	 				objService.putdata(accNo, name, contact,dateOfBirth, balance);
	 				System.out.println("Your Accno Is "+accNo);
	 				break;
	 		case 2:
	 				
	 				HashMap<Integer,Customer> allAccDetailsHahMap=objService.showdetails();
	 				Set<Integer> allAccDetailsSet=allAccDetailsHahMap.keySet();
	 				Iterator<Integer> allAccDetailsIterator=allAccDetailsSet.iterator();
	 				while(allAccDetailsIterator.hasNext())
	 				{
	 					int i=allAccDetailsIterator.next();
	 					Customer CustomerTemporaryVariable=allAccDetailsHahMap.get(i);
	 					System.out.println(CustomerTemporaryVariable);		
	 						
	 				}
	 				break;
	 		case 3:
	 				objService.showdetails();
	 				System.out.println("enter your AccNo");
	 				int accNoCustomer=sc.nextInt();
	 				System.out.println("enter balance to withdraw");
	 				double balanceToWithdraw=sc.nextDouble();
	 				try {
	 					objService.withdraw(accNoCustomer,balanceToWithdraw);
	 				} catch (BankException e) {
	 					// TODO Auto-generated catch block
	 					System.out.println(e.getMessage());;
	 				}
	 				break;
	 		case 4:
	 				objService.showdetails();
	 				System.out.println("enter your AccNo");
	 				int accNoCustomerDepositer=sc.nextInt();
	 				System.out.println("enter balance to deposit");
	 				double balanceToDeposit=sc.nextDouble();
	 				try {
	 					objService.deposit(accNoCustomerDepositer,balanceToDeposit);
	 				} catch (BankException e) {
	 					// TODO Auto-generated catch block
	 					System.out.println(e.getMessage());
	 				}
 					break;
	 		case 5:
	 				objService.showdetails();
	 				System.out.println("enter your accNo and the accNo you want to transfer");
	 				int idSender=sc.nextInt();
	 				int idReceiver=sc.nextInt();
	 				System.out.println("enter amount to transfer");
	 				double amountToTransfer=sc.nextDouble();
	 				String transactionDetail="";
	 				try {
	 					transactionDetail=objService.transaction(idSender,idReceiver,amountToTransfer);
	 				} catch (BankException e) {
	 					// TODO Auto-generated catch block
	 					System.out.println(e.getMessage());
	 				}
	 				System.out.println(transactionDetail);
	 				break;
	 		case 6:
	 				System.out.println("enter name to search");
	 				String nameToSearch=sc.next();
	 				String searchDetail="";
	 				try {
	 					searchDetail=objService.search(nameToSearch);
	 				} catch (BankException e) {
	 					// TODO Auto-generated catch block
	 					e.printStackTrace();
	 				}
	 				System.out.println(searchDetail);
	 				break;
	 				
	 		case 7:
	 				objService.showdetails();
	 				System.out.println("enter the accNo you want to see all transaction details");
	 				int accNoToFindTransactionDetails=sc.nextInt();
	 				
	 				ArrayList<String> customerAllTransaction=objService.printTransaction(accNoToFindTransactionDetails);
	 				Iterator<String> customerAllTransactionIterator=customerAllTransaction.iterator();
	 				System.out.println("All Transactions are:--------");
	 				while(customerAllTransactionIterator.hasNext())
	 				{
	 					System.out.println(customerAllTransactionIterator.next());
	 				}
	 				break;
	 			
	 		case 8:
	 				System.exit(1);
	 				break;
	 		default:
	 				System.out.println("wrong input");
	 				
	 		}
	 	
	 	}while(true);
	
 	}
}
