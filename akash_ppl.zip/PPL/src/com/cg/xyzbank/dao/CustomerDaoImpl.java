package com.cg.xyzbank.dao;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import com.cg.xyzbank.bean.Customer;
import com.cg.xyzbank.exception.BankException;
import com.cg.xyzbank.util.CollectionUtil;



public class CustomerDaoImpl implements ICustomerDao
{

	//HashMap<Integer,Customer> hm=new HashMap<>();
	CollectionUtil objCollectionUtil=new CollectionUtil();
	
	public void putdata(int id, String name, long contact,LocalDate date, double balance) 
	{
		// TODO Auto-generated method stub
		Customer customer=new Customer();
		customer.setAccNo(id);
		customer.setName(name);
		customer.setContact(contact);
		customer.setDate(date);
		customer.setBalance(balance);
		
		objCollectionUtil.setAllAccDetails(customer);
		
		//hm.put(customer.getAccNo(),customer);
		
	}

	@Override
	public HashMap<Integer, Customer> showdetails() {
		// TODO Auto-generated method stub
		
		return objCollectionUtil.getAllAccDetails();
	
	}

	@Override
	public void withdraw(int accNo, double balanceToWithdraw) throws BankException {
		// TODO Auto-generated method stub
		try {
		HashMap<Integer,Customer> allAccDetailsHahMap=objCollectionUtil.getAllAccDetails();
		Customer customerToWithdraw=allAccDetailsHahMap.get(accNo);
		double currentBalance=customerToWithdraw.getBalance();
		if(currentBalance>balanceToWithdraw)
		{
			double remainingBalance=currentBalance-balanceToWithdraw;
			if(remainingBalance>500)
			{
				ArrayList<String> withdrawDetails=customerToWithdraw.getList();
				String withdrawDetailsStr=customerToWithdraw.getName()+" withdraw "+balanceToWithdraw+" from account "+" on "+ LocalDate.now()+" at "+LocalTime.now();
				withdrawDetails.add(withdrawDetailsStr);
				customerToWithdraw.setList(withdrawDetails);
				
				customerToWithdraw.setBalance(remainingBalance);
			}
			else
			{
				throw new BankException("sorry you do not have enough balance min Balance in account policy is violated");
			}
				
		}
		else
			throw new BankException("sorry you do not have enough balance");
		}
		catch(NullPointerException e)
		{
			throw new BankException("sorry invalid account");
		}
	}

	@Override
	public void deposit(int accNo, double balanceToDeposit) throws BankException {
		
		// TODO Auto-generated method stub
		try {
		HashMap<Integer,Customer> allAccDetailsHahMap=objCollectionUtil.getAllAccDetails();
		Customer customerToDeposit=allAccDetailsHahMap.get(accNo);
		double currentBalance=customerToDeposit.getBalance();
		double temporaryCurrentBalance= currentBalance+balanceToDeposit;
		
			ArrayList<String> depositDetails=customerToDeposit.getList();
			String depositDetailsStr=customerToDeposit.getName()+" deposited "+balanceToDeposit+" on "+ LocalDate.now()+" at "+LocalTime.now();
			depositDetails.add(depositDetailsStr);
			customerToDeposit.setList(depositDetails);
			
			customerToDeposit.setBalance(temporaryCurrentBalance);
		}
		catch(NullPointerException e)
		{
			throw new BankException("sorry invalid account"); 
			
		}
	
		
		
	}
	public String transaction(int idSender,int idReceiver,double amountToTransfer) throws BankException
	{
		String transactionDetail="";
		try {
			
		
		HashMap<Integer,Customer> allAccDetailsHahMap=objCollectionUtil.getAllAccDetails();
		Customer customerToSend=allAccDetailsHahMap.get(idSender);
		Customer customerToReceive=allAccDetailsHahMap.get(idReceiver);
		double cuurentBalanceSender=customerToSend.getBalance();
		if(cuurentBalanceSender>amountToTransfer)
		{
			double temporaryCurrentBalance=cuurentBalanceSender-amountToTransfer;
			if(temporaryCurrentBalance>500)
			{
				double temporaryBalanceReceiver=customerToReceive.getBalance()+amountToTransfer;
		
					customerToReceive.setBalance(temporaryBalanceReceiver);
					customerToSend.setBalance(temporaryCurrentBalance);
					
					ArrayList<String> senderTransactionDetail=customerToSend.getList();
					String senderTransactionDetailStr=customerToSend.getName()+" Transfered "+amountToTransfer+" to "+customerToReceive.getName()+" on "+ LocalDate.now()+" at "+LocalTime.now()+"   "+"Current Balance = "+ customerToSend.getBalance();
					senderTransactionDetail.add(senderTransactionDetailStr);
					customerToSend.setList(senderTransactionDetail);
					
					ArrayList<String> receiverTransactionDetail=customerToReceive.getList();
					String receiverTransactionDetailStr=customerToSend.getName()+" Transfered "+amountToTransfer+" to "+customerToReceive.getName()+" on "+ LocalDate.now()+" at "+LocalTime.now()+"   "+"Current Balance = "+ customerToReceive.getBalance();
					receiverTransactionDetail.add(receiverTransactionDetailStr);
					customerToReceive.setList(receiverTransactionDetail);
					
					transactionDetail=customerToSend.getName()+" Transfered "+amountToTransfer+" to "+customerToReceive.getName()+" on "+ LocalDate.now()+" at "+LocalTime.now()+"   "+"Current Balance = "+ customerToSend.getBalance();
				
			}
			else
			{
				throw new BankException("sorry you do not have enough balance min Balance in account policy is violated");
			}
				
		}
		else
			throw new BankException("sorry you do not have enough balance");
		}
		catch(NullPointerException e)
		{
			throw new BankException("sorry invalid account"); 
		}
		return transactionDetail;
		
	}
	public String search(String customerToFindName) throws BankException
	{
		String searchDetail="";
		try {
			
		HashMap<Integer,Customer> allAccDetailsHahMap=objCollectionUtil.getAllAccDetails();
		Set<Integer> allAccDetailsSet=allAccDetailsHahMap.keySet();
		Iterator<Integer>  allAccDetailsiterator=allAccDetailsSet.iterator();
		while(allAccDetailsiterator.hasNext())
		{
			int i=allAccDetailsiterator.next();
			Customer customerToFind=allAccDetailsHahMap.get(i);
			if(customerToFind.getName().equals(customerToFindName))
			{
				searchDetail=""+customerToFind+"";
				break;
			}
			else
				searchDetail="record not found";	
				
		}
		}
		catch(NullPointerException e)
		{
			throw new BankException("sorry invalid account"); 
		}
		return searchDetail;
	}
	public ArrayList<String> printTransaction(int accNoToFindTransactionDetails)
	{
		HashMap<Integer,Customer> allAccDetailsHahMap=objCollectionUtil.getAllAccDetails();
		ArrayList<String> customerAllTransaction=allAccDetailsHahMap.get(accNoToFindTransactionDetails).getList();
		return customerAllTransaction;
/*		Iterator<String> itr=customerAllTransaction.iterator();
		System.out.println("All Transactions are:--------");
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
	*/
		
	}

}
